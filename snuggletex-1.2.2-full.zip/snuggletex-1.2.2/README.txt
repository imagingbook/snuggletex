SnuggleTeX
==========

Welcome to SnuggleTeX!

Information on using SnuggleTeX can be found at:

http://www.ph.ed.ac.uk/snuggletex/
